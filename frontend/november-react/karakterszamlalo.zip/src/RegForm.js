import React from "react";
import TextBox from "./TextBox";

export default class RegForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            userName: '',
            password: '',
            showPassword: false,
        }
    }

    handleShowPasswordClick = () => {
        this.setState({
            showPassword: !this.state.showPassword
        });
    };

    handleUserNameChange = (newUserName) => {
        this.setState({
            userName: newUserName,
        });
    };

    handlePasswordChange = (newPassword) => {
        this.setState({
            password: newPassword,
        });
    };

    render() {
        console.log(this.state);
        const { password, showPassword, userName } = this.state;

        return <div>
            Username:
            <TextBox
                inputId="username"
                text={userName}
                textLength={4}
                onChange={this.handleUserNameChange}
            />
            Password:
            <TextBox
                text={password}
                textLength={8}
                min={true}
                type={showPassword ? 'text' : 'password'}
                onChange={this.handlePasswordChange}
            />
            <button onClick={this.handleShowPasswordClick}>{showPassword ? 'Hide' : 'Show'}</button>
        </div>
    }
}