import logo from './logo.svg';
import './App.css';
import RegForm from './RegForm';

function App() {
  return (
    <div className="App">
      <RegForm />
    </div>
  );
}

export default App;
